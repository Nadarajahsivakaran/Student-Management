;
<?php $__env->startSection('content'); ?>

    <button type="button" class="btn btn-success add" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Add
    </button>


    <div class="container">

        <h1>Student Guardian Details</h1>

        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <th scope="col">Student</th>
                    <th scope="col">Guardian</th>
                    <th scope="col">Contact No</th>
                    <th scope="col">Address</th>
                    <th scope="col">Relation</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $studentGuardians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentGuardian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($studentGuardian->fullName); ?></td>
                        <td><?php echo e($studentGuardian->giardianName); ?></td>
                        <td><?php echo e($studentGuardian->contactNo); ?></td>
                        <td><?php echo e($studentGuardian->Address); ?></td>
                        <td><?php echo e($studentGuardian->relation); ?></td>
                        <td><button type="button" class="btn btn-primary edit" data-bs-toggle="modal"
                                data-bs-target="#exampleModal" onclick="edit(<?php echo e($studentGuardian->id); ?>)">Edit</button>
                        </td>
                        <td><a href="/guarianDelete/<?php echo e($studentGuardian->id); ?>" type="button"
                                onclick="return confirm('Are you sure you want to delete this item')"
                                class="btn btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Student Guardian</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">

                        <form action="/studentGuardianAdd" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="id" name="id">

                            <div class="mb-3">
                                <label for="student_id" class="form-label">Student</label>
                                <select class="form-select" aria-label="Default select example" name="student_id"
                                    id="student_id" value="<?php echo e(old('student_id')); ?>">
                                    <option value="" disabled selected>Please Select Student</option>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->fullName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="contactNo" class="form-label">Contact No</label>
                                <input type="number" class="form-control" id="contactNo" name="contactNo"
                                    value="<?php echo e(old('contactNo')); ?>">
                                <?php $__errorArgs = ['contactNo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" class="form-control" id="address" name="address"
                                    value="<?php echo e(old('address')); ?>">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="relation" class="form-label">Relation</label>
                                <input type="text" class="form-control" id="relation" name="relation"
                                    value="<?php echo e(old('relation')); ?>">
                                <?php $__errorArgs = ['relation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger reset">Reset</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>



    <script>
        $(document).ready(function() {

            if (!<?php echo json_encode($errors->isEmpty(), 15, 512) ?>) {
                $('#exampleModal').modal('show');
            }

        });

        $('.add').click(function() {
            $("#exampleModalLabel").empty().append('Create Student Guardian');
            $('.reset').show();
            $("#student_id").val("");
            $("#name").val("");
            $("#contactNo").val("");
            $("#address").val("");
            $("#relation").val("");
            $("#id").val("");
        });

        function edit(id) {

            $("#exampleModalLabel").empty().append('Update Student Guardian');
            $('.reset').hide();

            $.ajax({
                type: "GET",
                url: "/studentGuardianEdit/" + id,
                dataType: "json",

                success: function(response) {
                    $("#student_id").val(response.student_id);
                    $("#name").val(response.giardianName);
                    $("#contactNo").val(response.contactNo);
                    $("#address").val(response.Address);
                    $("#relation").val(response.relation);
                    $("#id").val(response.id);
                },

                error: function(response) {

                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\IMS\Task\resources\views/guardian.blade.php ENDPATH**/ ?>