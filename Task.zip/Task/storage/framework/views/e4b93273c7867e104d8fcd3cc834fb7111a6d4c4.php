<?php $__env->startSection('content'); ?>

    <button type="button" class="btn btn-success add" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Add
    </button>

    <div class="container">

        <h1>Student Details</h1>

        <table class="table table-hover" id="myTable">
            <thead>
                <tr>
                    <th scope="col">Full Name</th>
                    <th scope="col">Name With Initial</th>
                    <th scope="col">Address</th>
                    <th scope="col">DOB</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Registered Date</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>

            <tbody>

                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->fullName); ?></td>
                        <td><?php echo e($student->nameWithInitial); ?></td>
                        <td><?php echo e($student->address); ?></td>
                        <td><?php echo e($student->dob); ?></td>
                        <td><?php echo e($student->gender); ?></td>
                        <td>
                            <?php if($student->photo): ?>
                                <img src="<?php echo e(asset('student/' . $student->photo)); ?>" width="100" height="60">
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($student->registeredDate); ?></td>
                        <td><button type="button" class="btn btn-primary edit" data-bs-toggle="modal"
                                onclick="edit(<?php echo e($student->id); ?>)" data-bs-target="#exampleModal"><i
                                    class="far fa-edit"></i></button>
                        </td>
                        <td><a href="/studentDelete/<?php echo e($student->id); ?>" type="button" class="btn btn-danger"
                                onclick="return confirm('Are you sure you want to delete this item')"><i
                                    class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">

                        <form action="studentAdd" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="id" name="id">

                            <div class="mb-3">
                                <label for="fullName" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="fullName" name="fullName"
                                    value="<?php echo e(old('fullName')); ?>">
                                <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="nameWithInitial" class="form-label">Name with Initial</label>
                                <input type="text" class="form-control" id="nameWithInitial" name="nameWithInitial"
                                    value="<?php echo e(old('nameWithInitial')); ?>">
                                <?php $__errorArgs = ['nameWithInitial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" class="form-control" id="address" name="address"
                                    value="<?php echo e(old('address')); ?>">
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="dob" class="form-label">Date of Birth</label>
                                <input type="date" class="form-control" id="dob" name="dob"
                                    value="<?php echo e(old('dob')); ?>">
                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="gender" class="form-label">Gender</label>
                                <select class="form-select" aria-label="Default select example" name="gender"
                                    id="gender" value="<?php echo e(old('gender')); ?>">
                                    <option value="" disabled selected>Please Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="mb-3">
                                <label for="photo" class="form-label">Photo</label>
                                <input class="form-control" type="file" id="photo" name="photo"
                                    value="<?php echo e(old('photo')); ?>">
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="registeredDate" class="form-label"> Registered Date</label>
                                <input type="date" class="form-control" id="registeredDate" name="registeredDate"
                                    value="<?php echo e(old('registeredDate')); ?>">
                                <?php $__errorArgs = ['registeredDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span style="color: rgb(151, 4, 4); font-weight:bolder"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger reset">Reset</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
                </form>
            </div>
        </div>
    </div>


    <script>
        $(document).ready(function() {

            if (!<?php echo json_encode($errors->isEmpty(), 15, 512) ?>) {
                $('#exampleModal').modal('show');
            }

        });



        $('.add').click(function() {
            $("#exampleModalLabel").empty().append('Create Student');
            $('.reset').show();
            $('#id').val("");
            $('#fullName').val("");
            $('#address').val("");
            $('#nameWithInitial').val("");
            $('#dob').val("");
            $('#gender').val("");
            $('#photo').val("");
            $('#registeredDate').val("");

        })

        function edit(id) {

            $("#exampleModalLabel").empty().append('Update Student');
            $('.reset').hide();

            $.ajax({
                type: "GET",
                url: "/studentEdit/" + id,
                dataType: "json",

                success: function(response) {
                    $('#registeredDate').val(response.registeredDate);
                    $('#id').val(response.id);
                    $('#fullName').val(response.fullName);
                    $('#address').val(response.address);
                    $('#nameWithInitial').val(response.nameWithInitial);
                    $('#dob').val(response.dob);
                    $('#gender').val(response.gender);
                    $('#photo').val(response.photo);


                },

                error: function(response) {

                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\IMS\Task\resources\views/student.blade.php ENDPATH**/ ?>